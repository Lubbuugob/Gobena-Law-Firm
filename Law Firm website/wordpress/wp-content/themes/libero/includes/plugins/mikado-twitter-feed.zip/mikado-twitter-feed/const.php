<?php
define('MIKADO_TWITTER_FEED_VERSION', '1.1.1');
define('MIKADO_TWITTER_ABS_PATH', dirname(__FILE__));
define('MIKADO_TWITTER_REL_PATH', dirname(plugin_basename(__FILE__ )));