<?php

//Pie Chart Basic
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/piecharts/piechartbasic/load.php';

//Pie Chart Basic
include_once MIKADO_CORE_ABS_PATH.'/shortcodes/piecharts/piechartwithicon/load.php';