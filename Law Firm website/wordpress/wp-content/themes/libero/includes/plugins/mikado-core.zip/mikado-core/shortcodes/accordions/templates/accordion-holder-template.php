<div class="mkd-accordion-holder clearfix <?php echo esc_attr($acc_class)?> ">
	<?php echo libero_mikado_remove_wpautop($content)?>
</div>