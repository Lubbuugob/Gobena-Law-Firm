<?php

include_once MIKADO_CORE_ABS_PATH.'/shortcodes/service-table/service-table.php';