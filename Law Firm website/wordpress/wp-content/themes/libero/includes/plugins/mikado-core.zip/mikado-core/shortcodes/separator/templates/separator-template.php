<div class="mkd-separator-holder clearfix  <?php echo esc_attr($separator_class); ?>" <?php libero_mikado_inline_style($separator_holder_style); ?>>
	<div class="mkd-separator" <?php libero_mikado_inline_style($separator_style); ?>></div>
</div>
