<?php

if (libero_mikado_is_woocommerce_installed()) {
	include_once MIKADO_CORE_ABS_PATH.'/widgets/woocommerce-dd-cart/woocommerce-dropdown-cart.php';
}