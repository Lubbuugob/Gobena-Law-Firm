<?php
/**
 * Vertical Separator shortcode template
 */
?>

<span class='mkd-vertical-separator' <?php libero_mikado_inline_style($separator_style);?>></span>